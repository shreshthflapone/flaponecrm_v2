const svgToDataUrl = (svg) =>
  'data:image/svg+xml;utf-8,' + encodeURIComponent(svg);


export default svgToDataUrl;

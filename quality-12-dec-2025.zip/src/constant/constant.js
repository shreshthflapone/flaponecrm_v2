  //const base_url = "http://local.flapone.noida/flapone-api/flapone-api-3.0/kumb";
 const base_url = "https://www.flapone.com/flapone-api/flapone-api-3.0/kumb";

export default {base_url}
